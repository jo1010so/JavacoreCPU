package com.jojo.Register;

public interface RegisterConstants {
    Integer AX = 0,BX = 0,CX = 0,DX = 0,X = 0;
    Integer AH = 1,BH = 1,CH = 1,DH = 1,H = 1;
    Integer AL = 2,BL = 2,CL = 2,DL = 2,L = 2;
}

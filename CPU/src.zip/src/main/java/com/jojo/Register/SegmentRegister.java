package com.jojo.Register;

public class SegmentRegister extends Register{
    public SegmentRegister(String name, Integer size) {
        super(name, size);
    }
}
